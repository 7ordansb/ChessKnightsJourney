/**
 * Logic module for chess piece movement rules
 */

import { PIECE_MOVEMENTS } from './definitions.js';
import { gameState } from './state.js';

/**
 * Calculate all valid moves for a given piece from the player's current position
 * @param {Object} playerPos - The current position of the player {row, col}
 * @param {Object} card - The card object with piece type
 * @returns {Array} Array of valid move coordinates [{row, col}]
 */
export function calculateValidMoves(playerPos, card) {
    if (!card) {
        return [];
    }

    const pieceType = card.id; // Use card.id instead of card.piece.type
    const movements = PIECE_MOVEMENTS[pieceType];
    
    if (!movements) {
        return [];
    }

    const validMoves = [];
    const { row: currentRow, col: currentCol } = playerPos;

    // Handle different movement patterns based on piece type
    if (movements.type === 'fixed') {
        // For pieces with fixed movement patterns (like Knight)
        for (const move of movements.patterns) {
            const newRow = currentRow + move.row;
            const newCol = currentCol + move.col;
            
            // Check if the new position is within board bounds (assuming 8x8 board)
            if (isValidPosition(newRow, newCol)) {
                // Special handling for Pawn - it can move forward or capture diagonally
                if (pieceType === 'pawn') {
                    // Forward move (only to empty squares)
                    if (move.row === -1 && move.col === 0) {
                        if (!isSquareOccupiedByEnemy(newRow, newCol)) {
                            validMoves.push({ row: newRow, col: newCol });
                        }
                    }
                    // Diagonal capture (only to squares with enemies)
                    else if (move.row === -1 && Math.abs(move.col) === 1) {
                        if (isSquareOccupiedByEnemy(newRow, newCol)) {
                            validMoves.push({ row: newRow, col: newCol });
                        }
                    }
                } else {
                    // For other pieces, just check if position is valid
                    validMoves.push({ row: newRow, col: newCol });
                }
            }
        }
    } else if (movements.type === 'directional') {
        // For pieces that move in directions (like Rook, Bishop, Queen)
        for (const direction of movements.patterns) {
            let newRow = currentRow + direction.row;
            let newCol = currentCol + direction.col;
            
            // Continue in this direction until we hit the board edge
            while (isValidPosition(newRow, newCol)) {
                validMoves.push({ row: newRow, col: newCol });
                
                // For pieces that can only move one square in any direction (like King)
                if (movements.limited) {
                    break;
                }
                
                newRow += direction.row;
                newCol += direction.col;
            }
        }
    }

    return validMoves;
}

/**
 * Check if a position is valid on the board
 * @param {number} row - Row index
 * @param {number} col - Column index
 * @returns {boolean} True if position is valid
 */
function isValidPosition(row, col) {
    // Use the board size from gameState
    return row >= 0 && row < gameState.boardSize && col >= 0 && col < gameState.boardSize;
}

/**
 * Check if a square is occupied by an enemy
 * @param {number} row - Row index
 * @param {number} col - Column index
 * @returns {boolean} True if position has an enemy
 */
function isSquareOccupiedByEnemy(row, col) {
    return gameState.enemies.some(enemy => enemy.row === row && enemy.col === col);
}