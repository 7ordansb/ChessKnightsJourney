// state.js - Manages all game data
import { PLAYER_STARTING_DECK, LEVEL_DEFINITIONS, UPGRADE_DEFINITIONS } from './definitions.js';

// Function to generate a unique ID for cards
function generateCardId(baseId, counter) {
  return `${baseId}_${counter}`;
}

export const gameState = {
  boardSize: 6, // 6x6 board
  board: [],
  gameObjects: [], // List of all game objects including the player
  deck: [],      // Player's deck of cards
  hand: [],      // Player's hand of cards (max 2)
  nextCard: null, // Next card in the deck (not playable)
 discardPile: [], // Cards that have been played
 selectedCard: null,
  highlightedSquares: [],
  currentLevel: 1,
  enemies: [],
 actionsRemaining: 1, // New property for action points system
 playerHealth: 3, // Player's current health
 playerMaxHealth: 3, // Player's maximum health
 playerArmor: 1 // Player's temporary armor (starter shield)
};

// Function to start a new player turn
export function startNewTurn() {
  gameState.actionsRemaining = 1;
  console.log('New turn started. Actions remaining:', gameState.actionsRemaining);
}

// Function to move the player to a new position
export function movePlayer(newRow, newCol) {
  const player = gameState.gameObjects.find(obj => obj.type === 'player');
  if (player) {
    player.row = newRow;
    player.col = newCol;
    return true;
 }
  return false;
}

// Function to shuffle an array using Fisher-Yates algorithm
export function shuffleArray(array) {
  const newArray = [...array]; // Create a copy to avoid mutating the original
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}

// Function to use a card and move it to the discard pile, then draw a new card
export function useCard(cardInstanceId) {
  const cardIndex = gameState.hand.findIndex(card => card.card_id === cardInstanceId);
  if (cardIndex !== -1) {
    // Move the used card from hand to discard pile
    const usedCard = gameState.hand.splice(cardIndex, 1)[0];
    gameState.discardPile.push(usedCard);
    
    // Draw a card from the top of the deck and add it to the hand
    if (gameState.deck.length > 0) {
      const drawnCard = gameState.deck.shift(); // Remove card from top of deck
      gameState.hand.push(drawnCard);
    }
    
    // Update the nextCard to be the new top card of the deck (just a preview)
    if (gameState.deck.length > 0) {
      gameState.nextCard = {...gameState.deck[0]}; // Create a copy for preview only
    } else if (gameState.discardPile.length > 0) {
      // If deck is empty, reshuffle the discard pile back into the deck
      gameState.deck = shuffleArray([...gameState.discardPile]);
      gameState.discardPile = []; // Clear the discard pile
      
      // Now update the nextCard from the reshuffled deck if possible
      if (gameState.deck.length > 0) {
        gameState.nextCard = {...gameState.deck[0]}; // Create a copy for preview only
      } else {
        gameState.nextCard = null;
      }
    } else {
      // If both deck and discard pile are empty, set nextCard to null
      gameState.nextCard = null;
    }
    
    return true;
  }
  return false;
}

// Function to clear highlights and selected card
export function clearSelection() {
  gameState.selectedCard = null;
  gameState.highlightedSquares = [];
}

// Function to setup the level with deck, hand, and discard pile
export function setupLevel() {
  // Create unique instances of each card in the playerStartingDeck
  let cardCounter = {};
  gameState.deck = [];
  let firstKnightFound = false; // Flag to track if we've added the upgrade to the first knight
  let firstBishopFound = false; // Flag to track if we've added the reverse upgrade to the first bishop
  let firstPawnFound = false; // Flag to track if we've added the armor upgrade to the first pawn
  
  for (const card of PLAYER_STARTING_DECK) {
    // Count how many of this card type we've already added
    const baseId = card.id;
    cardCounter[baseId] = (cardCounter[baseId] || 0) + 1;
    // Create a new card object with a unique ID
    let uniqueCard = {
      ...card, // Copy all properties from the original card
      card_id: generateCardId(baseId, cardCounter[baseId]) // Add unique instance ID
    };
    
    // Add upgrade to the first Knight card instance for testing
    if (card.id === 'knight' && !firstKnightFound) {
      uniqueCard.upgrades = [UPGRADE_DEFINITIONS.STAMINA_1];
      firstKnightFound = true;
    } else if (card.id === 'bishop' && !firstBishopFound) {
      // Add the Reverse upgrade to one of the Bishop cards for testing
      uniqueCard.upgrades = [UPGRADE_DEFINITIONS.REVERSE_1];
      firstBishopFound = true;
    } else if (card.id === 'pawn' && !firstPawnFound) {
      // Add the Armor upgrade to one of the Pawn cards for testing
      uniqueCard.upgrades = [UPGRADE_DEFINITIONS.ARMOR_1];
      firstPawnFound = true;
    } else {
      uniqueCard.upgrades = []; // Initialize empty upgrades array for other cards
    }

    gameState.deck.push(uniqueCard);
  }
  
  // Shuffle the state's deck array into a random order
  gameState.deck = shuffleArray(gameState.deck);
  
  // Move the first two cards from the shuffled deck into the hand
  gameState.hand = [];
  for (let i = 0; i < 2 && gameState.deck.length > 0; i++) {
    gameState.hand.push(gameState.deck.shift());
  }
  
  // Set the next card from the top of the deck
  gameState.nextCard = gameState.deck.length > 0 ? {...gameState.deck[0]} : null;
  
  // The discardPile should start empty
  gameState.discardPile = [];
  
  // Initialize actions remaining for the player's turn
  gameState.actionsRemaining = 1;
  
  console.log('Level setup complete:', { deck: gameState.deck, hand: gameState.hand, discardPile: gameState.discardPile });
}

// Initialize the board
export function initializeBoard() {
  gameState.board = [];
  for (let i = 0; i < gameState.boardSize; i++) {
    const row = [];
    for (let j = 0; j < gameState.boardSize; j++) {
      // Determine if the square should be black or white based on position
      // Chess board pattern: if (row + col) % 2 === 0, then white, else black
      const isWhite = (i + j) % 2 === 0;
      row.push({
        row: i,
        col: j,
        color: isWhite ? 'white' : 'black'
      });
    }
    gameState.board.push(row);
  }
}

// Initialize the board when the module loads
initializeBoard();

// Initialize player - positioned on third square from left in bottom row (row 5, col 2)
export function initializePlayer() {
  const player = {
    type: 'player',
    symbol: '♚', // Black king symbol
    row: 5, // Bottom row (0-indexed)
    col: 2, // Third square from left (0-indexed)
    element: null // Will store the DOM element when rendered
  };
  gameState.gameObjects.push(player);
}

// Initialize the player when the module loads
initializePlayer();

// Setup the level when the module loads (replaces initializePlayerHand)
setupLevel();

// Function to load level data
export function loadLevel(levelNum) {
  const levelKey = `level${levelNum}`;
  const levelData = LEVEL_DEFINITIONS[levelKey];
  if (levelData) {
    gameState.currentLevel = levelNum;
    gameState.enemies = [...levelData.enemies];
    console.log(`Level ${levelNum} loaded:`, gameState.enemies);
  } else {
    console.error(`Level ${levelNum} not found in definitions`);
  }
}

// Load the first level when the module loads
loadLevel(1);