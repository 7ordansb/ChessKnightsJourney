// Card definitions for the game
export const CARD_DEFINITIONS = {
  PAWN: {
     id: 'pawn',
     name: 'Pawn',
     symbol: '♙',
     description: 'Moves forward one square, captures diagonally'
   },
   KNIGHT: {
     id: 'knight',
     name: 'Knight',
     symbol: '♘',
     description: 'Moves in an L-shape: two squares in one direction and one square perpendicular'
   },
   BISHOP: {
     id: 'bishop',
     name: 'Bishop',
     symbol: '♗',
     description: 'Moves diagonally any number of squares'
   },
   ROOK: {
     id: 'rook',
     name: 'Rook',
     symbol: '♖',
     description: 'Moves horizontally or vertically any number of squares'
   }
};

// Array of starting cards
export const STARTING_CARDS = [
  CARD_DEFINITIONS.PAWN,
  CARD_DEFINITIONS.KNIGHT,
  CARD_DEFINITIONS.BISHOP,
  CARD_DEFINITIONS.ROOK
];

// Player's starting deck - two of each card type
export const PLAYER_STARTING_DECK = [
  CARD_DEFINITIONS.PAWN,
  CARD_DEFINITIONS.PAWN,
  CARD_DEFINITIONS.KNIGHT,
  CARD_DEFINITIONS.KNIGHT,
  CARD_DEFINITIONS.BISHOP,
  CARD_DEFINITIONS.BISHOP,
  CARD_DEFINITIONS.ROOK,
  CARD_DEFINITIONS.ROOK
];

// Define movement patterns for each piece type
export const PIECE_MOVEMENTS = {
  pawn: {
    type: 'fixed',
    patterns: [
      { row: -1, col: 0 }  // Moves forward one square (from white's perspective)
    ]
  },
  knight: {
    type: 'fixed',
    patterns: [
      { row: -2, col: -1 }, { row: -2, col: 1 },  // Up 2, left/right 1
      { row: -1, col: -2 }, { row: -1, col: 2 },  // Up 1, left/right 2
      { row: 1, col: -2 }, { row: 1, col: 2 },    // Down 1, left/right 2
      { row: 2, col: -1 }, { row: 2, col: 1 }     // Down 2, left/right 1
    ]
  },
  bishop: {
    type: 'directional',
    patterns: [
      { row: -1, col: -1 }, { row: -1, col: 1 },  // Diagonally up-left/up-right
      { row: 1, col: -1 }, { row: 1, col: 1 }     // Diagonally down-left/down-right
    ]
  },
  rook: {
    type: 'directional',
    patterns: [
      { row: -1, col: 0 }, { row: 1, col: 0 },    // Vertically up/down
      { row: 0, col: -1 }, { row: 0, col: 1 }     // Horizontally left/right
    ]
  }
};

// Level definitions
export const LEVEL_DEFINITIONS = {
  level1: {
    id: 'level1',
    name: 'The First Puzzle',
    description: 'Two menacing monsters appear on the board. Capture them with your King!',
    enemies: [
      { type: 'monster', symbol: '👹', row: 2, col: 2 },
      { type: 'monster', symbol: '👹', row: 2, col: 5 }
    ]
  }
};

// Upgrade definitions for the game
export const UPGRADE_DEFINITIONS = {
  STAMINA_1: {
    id: 'stamina_1',
    icon: '⚡',
    name: '+1 Stamina',
    description: 'Allows you to play another card this turn.',
    backgroundColor: '#FFD700' // Yellow/gold color for stamina
  },
  REVERSE_1: {
    id: 'reverse_1',
    icon: '⏪',
    name: 'Reverse',
    description: 'After moving, return to your starting square.',
    backgroundColor: '#87CEEB' // Light blue color for reverse
  },
  ARMOR_1: {
    id: 'armor_1',
    icon: '🛡️',
    name: '+1 Armor',
    description: 'Gain 1 temporary armor point when this card is played.',
    backgroundColor: '#90EE90' // Light green color for armor
  }
};