// ui.js - The renderer
import { gameState } from './state.js';

// Function to render the board
export function renderBoard() {
   // Clear any existing board
   const existingBoard = document.getElementById('chess-board');
   if (existingBoard) {
     existingBoard.remove();
 }
    
   // Create the board container
   const board = document.createElement('div');
   board.id = 'chess-board';
   board.className = 'chess-board';
   
   // Create squares for the board
   for (let i = 0; i < gameState.boardSize; i++) {
     for (let j = 0; j < gameState.boardSize; j++) {
       const square = document.createElement('div');
       square.className = `square ${gameState.board[i][j].color}`;
       square.dataset.row = i;
       square.dataset.col = j;
       
       // Check if this square should be highlighted
       const isHighlighted = gameState.highlightedSquares.some(highlightedSquare =>
         highlightedSquare.row === i && highlightedSquare.col === j
       );
       if (isHighlighted) {
         square.classList.add('highlighted');
       }
       
       board.appendChild(square);
     }
     
   }

   // Find the game container and add the board to it
   const gameContainer = document.getElementById('game-container');
   if (gameContainer) {
     gameContainer.appendChild(board);
   } else {
     // If no game container exists, add to body as fallback
     document.body.appendChild(board);
   }
   
   // Render game objects (like the player) after the board is in the DOM
   renderGameObjects();
   
   // Render the player's hand (hotbar) below the board
   renderPlayerHand();
   
   // Render the health display
  renderHealth();
 }

// Function to update game object positions without recreating them
export function updateGameObjectPositions() {
   // Update positions of player objects by moving them to their correct squares
   gameState.gameObjects.forEach(obj => {
     if (obj.element) {
       // Find the square element for this object's position
       const squareElement = document.querySelector(`.square[data-row="${obj.row}"][data-col="${obj.col}"]`);
       if (squareElement && obj.element.parentElement !== squareElement) {
         // Move the element to the correct square
         squareElement.appendChild(obj.element);
       }
     }
   });
   
   // Update positions of enemy objects by moving them to their correct squares
   gameState.enemies.forEach(enemy => {
     if (enemy.element) {
       // Find the square element for this enemy's position
       const squareElement = document.querySelector(`.square[data-row="${enemy.row}"][data-col="${enemy.col}"]`);
       if (squareElement && enemy.element.parentElement !== squareElement) {
         // Move the element to the correct square
         squareElement.appendChild(enemy.element);
       }
     }
   });
}

// Function to render game objects on the board
function renderGameObjects() {
      // First, find the chess board element to calculate square dimensions
      const boardElement = document.getElementById('chess-board');
      if (!boardElement) return;
      
      // Calculate square dimensions based on the board size
      const positionGameObjects = () => {
          // Render player objects
          gameState.gameObjects.forEach(obj => {
              // Find the square element for this object's position
              const squareElement = document.querySelector(`.square[data-row="${obj.row}"][data-col="${obj.col}"]`);
              if (!squareElement) return;
              
              // Create a game object element if it doesn't exist
              let objElement = obj.element;
              if (!objElement) {
                  objElement = document.createElement('div');
                  objElement.className = 'game-object';
                  objElement.textContent = obj.symbol;
                  objElement.style.fontSize = '4.8rem'; // Doubled the size
                  
                  // Set initial transform to center the piece in its square
                  objElement.style.transform = 'translate(-50%, -50%)';
                  
                  // Add the game object to the square element
                  squareElement.appendChild(objElement);
                  
                  // Store reference to the element in the game object
                  obj.element = objElement;
              }
              // If the element already exists but is in the wrong square, move it
              else if (objElement.parentElement !== squareElement) {
                  // Move the element to the correct square
                  squareElement.appendChild(objElement);
              }
          });
          
          // Render enemies
          gameState.enemies.forEach(enemy => {
              // Find the square element for this enemy's position
              const squareElement = document.querySelector(`.square[data-row="${enemy.row}"][data-col="${enemy.col}"]`);
              if (!squareElement) return;
              
              // Create an enemy element if it doesn't exist
              let enemyElement = enemy.element;
              if (!enemyElement) {
                  enemyElement = document.createElement('div');
                  enemyElement.className = 'game-object';
                  enemyElement.textContent = enemy.symbol;
                  enemyElement.style.fontSize = '4.8rem'; // Doubled the size
                  
                  // Set initial transform to center the piece in its square
                  enemyElement.style.transform = 'translate(-50%, -50%)';
                  
                  // Add the enemy to the square element
                  squareElement.appendChild(enemyElement);
                  
                  // Store reference to the element in the enemy
                  enemy.element = enemyElement;
              }
              // If the element already exists but is in the wrong square, move it
              else if (enemyElement.parentElement !== squareElement) {
                  // Move the element to the correct square
                  squareElement.appendChild(enemyElement);
              }
          });
      };
      
      // Wait for the board to be rendered with proper dimensions
      requestAnimationFrame(() => {
          // Board is rendered, position objects now
          positionGameObjects();
      });
  }
    // Function to render the player's hand (hotbar)
   export function renderPlayerHand() {
 console.log('renderPlayerHand called, hand:', gameState.hand);
  // Clear any existing hotbar
  const existingHotbar = document.getElementById('hotbar');
  if (existingHotbar) {
    existingHotbar.remove();
 }

  // Create the hotbar container
  const hotbar = document.createElement('div');
  hotbar.id = 'hotbar';
  hotbar.className = 'hotbar';

  // Create a container for the hotbar label
  const hotbarLabel = document.createElement('div');
  hotbarLabel.className = 'hotbar-label';
  hotbarLabel.textContent = 'Your Cards:';
  hotbar.appendChild(hotbarLabel);

  // Create a container for the hotbar contents
         const hotbarContents = document.createElement('div');
         hotbarContents.className = 'hotbar-contents';
         
         // Add the deck button to the top-left of the hotbar
         const deckButton = document.createElement('button');
         deckButton.className = 'deck-button deck-button-fixed';
         deckButton.textContent = 'DECK';
         
         // Add mouse event listeners for tooltip
         deckButton.addEventListener('mouseenter', (e) => {
           const tooltip = document.getElementById('card-tooltip');
           if (tooltip) {
             // Populate tooltip with deck info
             const header = tooltip.querySelector('.tooltip-header');
             const body = tooltip.querySelector('.tooltip-body');
             
             if (header && body) {
               header.textContent = 'Deck';
               body.textContent = `Cards remaining: ${gameState.deck.length}`;
             }
             
             // Position the tooltip near the cursor
             const rect = deckButton.getBoundingClientRect();
             tooltip.style.left = rect.right + 10 + 'px'; // Position to the right of the button
             tooltip.style.top = rect.top + 'px'; // Align with top of the button
             
             // Show the tooltip
             tooltip.style.display = 'block';
           }
         });
         
         deckButton.addEventListener('mouseleave', () => {
           const tooltip = document.getElementById('card-tooltip');
           if (tooltip) {
             // Hide the tooltip
             tooltip.style.display = 'none';
           }
         });
         
         hotbar.appendChild(deckButton); // Add directly to hotbar to position it independently
         
         // Create a container for the next card
         const nextCardContainer = document.createElement('div');
         nextCardContainer.className = 'next-card-container';
         
         // Add the next card if available
         if (gameState.nextCard) {
           const nextCardElement = document.createElement('div'); // Not a button, so it's not clickable
           nextCardElement.className = 'card-button next-card'; // Different class for styling
           nextCardElement.dataset.cardId = gameState.nextCard.card_id;
           
           // Set the card symbol as the content
           nextCardElement.innerHTML = `<span class="card-symbol">${gameState.nextCard.symbol}</span>`;
           
           // Add upgrade icons if the card has upgrades
           if (gameState.nextCard.upgrades && gameState.nextCard.upgrades.length > 0) {
             const upgradesContainer = document.createElement('div');
             upgradesContainer.className = 'card-upgrades';
             
             gameState.nextCard.upgrades.forEach(upgrade => {
               const upgradeElement = document.createElement('span');
               upgradeElement.className = 'upgrade-icon';
               upgradeElement.textContent = upgrade.icon;
               // Apply the background color from the upgrade definition
               if (upgrade.backgroundColor) {
                 upgradeElement.style.backgroundColor = upgrade.backgroundColor;
               }
               upgradesContainer.appendChild(upgradeElement);
             });
             
             nextCardElement.appendChild(upgradesContainer);
           }
           
           // Add mouse event listeners for tooltip
           nextCardElement.addEventListener('mouseenter', (e) => {
             const tooltip = document.getElementById('card-tooltip');
             if (tooltip) {
               // Populate tooltip with card name and description
               const header = tooltip.querySelector('.tooltip-header');
               const body = tooltip.querySelector('.tooltip-body');
               
               if (header && body) {
                 header.textContent = gameState.nextCard.name;
                 body.textContent = gameState.nextCard.description;
                 
                 // Check if the card has upgrades and render them
                 if (gameState.nextCard.upgrades && gameState.nextCard.upgrades.length > 0) {
                   const upgradesContainer = document.createElement('div');
                   upgradesContainer.className = 'tooltip-upgrades';
                   upgradesContainer.style.marginTop = '8px';
                   upgradesContainer.style.paddingTop = '8px';
                   upgradesContainer.style.borderTop = '1px solid #666';
                   
                   gameState.nextCard.upgrades.forEach(upgrade => {
                     // Create a container for the upgrade (icon + text)
                     const upgradeLine = document.createElement('div');
                     upgradeLine.className = 'upgrade-line';
                     
                     const upgradeElement = document.createElement('span');
                     upgradeElement.className = 'upgrade-icon';
                     upgradeElement.textContent = upgrade.icon;
                     // Apply the background color from the upgrade definition
                     if (upgrade.backgroundColor) {
                       upgradeElement.style.backgroundColor = upgrade.backgroundColor;
                     }
                     
                     // Create a text element with the name
                     const upgradeText = document.createElement('span');
                     upgradeText.className = 'upgrade-text';
                     upgradeText.textContent = upgrade.name; // This will show "+1 Stamina"
                     
                     upgradeLine.appendChild(upgradeElement);
                     upgradeLine.appendChild(upgradeText);
                     
                     // Add tooltip functionality to the entire upgrade line
                     upgradeLine.addEventListener('mouseenter', (e) => {
                       const tooltip = document.getElementById('card-tooltip');
                       if (tooltip) {
                         // Populate tooltip with upgrade name and description
                         const header = tooltip.querySelector('.tooltip-header');
                         const body = tooltip.querySelector('.tooltip-body');
                         
                         if (header && body) {
                           header.textContent = upgrade.name;
                           body.textContent = upgrade.description;
                         }
                         
                         // Position the tooltip near the cursor
                         const rect = upgradeLine.getBoundingClientRect();
                         tooltip.style.left = rect.right + 10 + 'px'; // Position to the right of the icon
                         tooltip.style.top = rect.top + 'px'; // Align with top of the icon
                         
                         // Show the tooltip
                         tooltip.style.display = 'block';
                       }
                     });
                     
                     upgradeLine.addEventListener('mouseleave', () => {
                       const tooltip = document.getElementById('card-tooltip');
                       if (tooltip) {
                         // Hide the tooltip
                         tooltip.style.display = 'none';
                       }
                     });
                     
                     upgradesContainer.appendChild(upgradeLine);
                   });
                   
                   // Add the upgrades container to the tooltip body
                   body.appendChild(upgradesContainer);
                 }
               }
               
               // Position the tooltip near the cursor
               const rect = nextCardElement.getBoundingClientRect();
               tooltip.style.left = rect.right + 10 + 'px'; // Position to the right of the card
               tooltip.style.top = rect.top + 'px'; // Align with top of the card
               
               // Show the tooltip
               tooltip.style.display = 'block';
             }
           });
           
           nextCardElement.addEventListener('mouseleave', () => {
             const tooltip = document.getElementById('card-tooltip');
             if (tooltip) {
               // Hide the tooltip
               tooltip.style.display = 'none';
             }
           });
           
           // Add a "Next" label overlay
           const nextLabel = document.createElement('div');
           nextLabel.className = 'next-label';
           nextLabel.textContent = 'NEXT';
           nextCardElement.appendChild(nextLabel);
           
           nextCardContainer.appendChild(nextCardElement);
         }
         
         // Add the next card container to the main container first (so it appears at the start)
         hotbarContents.appendChild(nextCardContainer);
         
         // Create a container specifically for the playable cards
         const playableCardsContainer = document.createElement('div');
         playableCardsContainer.className = 'playable-cards';
         
         // Create card elements for each card in the player's hand
         if (gameState.hand && gameState.hand.length > 0) {
           gameState.hand.forEach((card, index) => {
             const cardElement = document.createElement('button');
             cardElement.className = 'card-button';
             cardElement.dataset.cardId = card.card_id; // Use the unique card instance ID
             cardElement.dataset.cardIndex = index;
             
             // Check if this card is currently selected
             if (gameState.selectedCard && gameState.selectedCard.card_id === card.card_id) {
               cardElement.classList.add('selected');
             }
             
             // Set the card symbol as the content
             cardElement.innerHTML = `<span class="card-symbol">${card.symbol}</span>`;
             
             // Add upgrade icons if the card has upgrades
             if (card.upgrades && card.upgrades.length > 0) {
               const upgradesContainer = document.createElement('div');
               upgradesContainer.className = 'card-upgrades';
               
               card.upgrades.forEach(upgrade => {
                 const upgradeElement = document.createElement('span');
                 upgradeElement.className = 'upgrade-icon';
                 upgradeElement.textContent = upgrade.icon;
                 // Apply the background color from the upgrade definition
                 if (upgrade.backgroundColor) {
                   upgradeElement.style.backgroundColor = upgrade.backgroundColor;
                 }
                 upgradesContainer.appendChild(upgradeElement);
               });
               
               cardElement.appendChild(upgradesContainer);
             }
             
             // Add mouse event listeners for tooltip
             cardElement.addEventListener('mouseenter', (e) => {
               const tooltip = document.getElementById('card-tooltip');
               if (tooltip) {
                 // Populate tooltip with card name and description
                 const header = tooltip.querySelector('.tooltip-header');
                 const body = tooltip.querySelector('.tooltip-body');
                 
                 if (header && body) {
                   header.textContent = card.name;
                   body.textContent = card.description;
                   
                   // Check if the card has upgrades and render them
                   if (card.upgrades && card.upgrades.length > 0) {
                     const upgradesContainer = document.createElement('div');
                     upgradesContainer.className = 'tooltip-upgrades';
                     upgradesContainer.style.marginTop = '8px';
                     upgradesContainer.style.paddingTop = '8px';
                     upgradesContainer.style.borderTop = '1px solid #666';
                     
                     card.upgrades.forEach(upgrade => {
                       // Create a container for the upgrade (icon + text)
                       const upgradeLine = document.createElement('div');
                       upgradeLine.className = 'upgrade-line';
                       
                       const upgradeElement = document.createElement('span');
                       upgradeElement.className = 'upgrade-icon';
                       upgradeElement.textContent = upgrade.icon;
                       // Apply the background color from the upgrade definition
                       if (upgrade.backgroundColor) {
                         upgradeElement.style.backgroundColor = upgrade.backgroundColor;
                       }
                       
                       // Create a text element with the name
                       const upgradeText = document.createElement('span');
                       upgradeText.className = 'upgrade-text';
                       upgradeText.textContent = upgrade.name; // This will show "+1 Stamina"
                       
                       upgradeLine.appendChild(upgradeElement);
                       upgradeLine.appendChild(upgradeText);
                       
                       // Add tooltip functionality to the entire upgrade line
                       upgradeLine.addEventListener('mouseenter', (e) => {
                         const tooltip = document.getElementById('card-tooltip');
                         if (tooltip) {
                           // Populate tooltip with upgrade name and description
                           const header = tooltip.querySelector('.tooltip-header');
                           const body = tooltip.querySelector('.tooltip-body');
                           
                           if (header && body) {
                             header.textContent = upgrade.name;
                             body.textContent = upgrade.description;
                           }
                           
                           // Position the tooltip near the cursor
                           const rect = upgradeLine.getBoundingClientRect();
                           tooltip.style.left = rect.right + 10 + 'px'; // Position to the right of the icon
                           tooltip.style.top = rect.top + 'px'; // Align with top of the icon
                           
                           // Show the tooltip
                           tooltip.style.display = 'block';
                         }
                       });
                       
                       upgradeLine.addEventListener('mouseleave', () => {
                         const tooltip = document.getElementById('card-tooltip');
                         if (tooltip) {
                           // Hide the tooltip
                           tooltip.style.display = 'none';
                         }
                       });
                       
                       upgradesContainer.appendChild(upgradeLine);
                     });
                     
                     // Add the upgrades container to the tooltip body
                     body.appendChild(upgradesContainer);
                   }
                 }
                 
                 // Position the tooltip near the cursor
                 const rect = cardElement.getBoundingClientRect();
                 tooltip.style.left = rect.right + 10 + 'px'; // Position to the right of the card
                 tooltip.style.top = rect.top + 'px'; // Align with top of the card
                 
                 // Show the tooltip
                 tooltip.style.display = 'block';
               }
             });
             
             cardElement.addEventListener('mouseleave', () => {
               const tooltip = document.getElementById('card-tooltip');
               if (tooltip) {
                 // Hide the tooltip
                 tooltip.style.display = 'none';
               }
             });
             
             playableCardsContainer.appendChild(cardElement);
           });
         } else {
           console.log('No cards in player hand');
           // Add a placeholder message if no cards are available
           const placeholder = document.createElement('div');
           placeholder.className = 'hotbar-placeholder';
           placeholder.textContent = 'No cards available';
           playableCardsContainer.appendChild(placeholder);
         }
         
         // Add the playable cards container to the main container
         hotbarContents.appendChild(playableCardsContainer);
         
         // Add the contents container to the main hotbar
         hotbar.appendChild(hotbarContents);

    // Removed old reference to cardsContainer that no longer exists

  // Add the hotbar to the page below the board
 document.body.appendChild(hotbar);
}

// Function to render the deck viewer modal content
export function renderDeckViewer(groupedCards) {
  // Get the container for the deck cards
  const container = document.getElementById('deck-cards-container');
  if (!container) {
    console.error('Deck cards container not found');
    return;
  }

  // Clear any previous content
  container.innerHTML = '';

  // Iterate over the grouped cards object
  for (const [cardType, cards] of Object.entries(groupedCards)) {
    // Create a title element for this card type
    const titleElement = document.createElement('h3');
    titleElement.className = 'deck-category-title';
    titleElement.textContent = cardType + 's'; // Add 's' to make it plural like "Pawns", "Knights"
    
    // Add the title to the container
    container.appendChild(titleElement);
    
    // Create a container for the cards in this category
    const categoryContainer = document.createElement('div');
    categoryContainer.className = 'deck-category-container';
    
    // Iterate through the array of card instances for this category
    cards.forEach(card => {
      // Create a container for this card
      const cardItem = document.createElement('div');
      cardItem.className = 'deck-card-item';
      
      // Create the card symbol element
      const symbolElement = document.createElement('div');
      symbolElement.className = 'deck-card-symbol';
      symbolElement.textContent = card.symbol;
      
      // Add the symbol element to the card item
      cardItem.appendChild(symbolElement);
      
      // Add upgrade icons if the card has upgrades
      if (card.upgrades && card.upgrades.length > 0) {
        const upgradesContainer = document.createElement('div');
        upgradesContainer.className = 'card-upgrades';
        
        card.upgrades.forEach(upgrade => {
          const upgradeElement = document.createElement('span');
          upgradeElement.className = 'upgrade-icon';
          upgradeElement.textContent = upgrade.icon;
          // Apply the background color from the upgrade definition
          if (upgrade.backgroundColor) {
            upgradeElement.style.backgroundColor = upgrade.backgroundColor;
          }
          upgradesContainer.appendChild(upgradeElement);
        });
        
        cardItem.appendChild(upgradesContainer);
      }
      
      // Add mouse event listeners for tooltip
      cardItem.addEventListener('mouseenter', (e) => {
        const tooltip = document.getElementById('card-tooltip');
        if (tooltip) {
          // Populate tooltip with card name and description
          const header = tooltip.querySelector('.tooltip-header');
          const body = tooltip.querySelector('.tooltip-body');
          
          if (header && body) {
            header.textContent = card.name;
            body.textContent = card.description;
            
            // Check if the card has upgrades and render them
            if (card.upgrades && card.upgrades.length > 0) {
              const upgradesContainer = document.createElement('div');
              upgradesContainer.className = 'tooltip-upgrades';
              upgradesContainer.style.marginTop = '8px';
              upgradesContainer.style.paddingTop = '8px';
              upgradesContainer.style.borderTop = '1px solid #666';
              
              card.upgrades.forEach(upgrade => {
                // Create a container for the upgrade (icon + text)
                const upgradeLine = document.createElement('div');
                upgradeLine.className = 'upgrade-line';
                
                const upgradeElement = document.createElement('span');
                upgradeElement.className = 'upgrade-icon';
                upgradeElement.textContent = upgrade.icon;
                // Apply the background color from the upgrade definition
                if (upgrade.backgroundColor) {
                  upgradeElement.style.backgroundColor = upgrade.backgroundColor;
                }
                
                // Create a text element with the name
                const upgradeText = document.createElement('span');
                upgradeText.className = 'upgrade-text';
                upgradeText.textContent = upgrade.name; // This will show "+1 Stamina"
                
                upgradeLine.appendChild(upgradeElement);
                upgradeLine.appendChild(upgradeText);
                
                // Add tooltip functionality to the entire upgrade line
                upgradeLine.addEventListener('mouseenter', (e) => {
                  const tooltip = document.getElementById('card-tooltip');
                  if (tooltip) {
                    // Populate tooltip with upgrade name and description
                    const header = tooltip.querySelector('.tooltip-header');
                    const body = tooltip.querySelector('.tooltip-body');
                    
                    if (header && body) {
                      header.textContent = upgrade.name;
                      body.textContent = upgrade.description;
                    }
                    
                    // Position the tooltip near the cursor
                    const rect = upgradeLine.getBoundingClientRect();
                    tooltip.style.left = rect.right + 10 + 'px'; // Position to the right of the icon
                    tooltip.style.top = rect.top + 'px'; // Align with top of the icon
                    
                    // Show the tooltip
                    tooltip.style.display = 'block';
                  }
                });
                
                upgradeLine.addEventListener('mouseleave', () => {
                  const tooltip = document.getElementById('card-tooltip');
                  if (tooltip) {
                    // Hide the tooltip
                    tooltip.style.display = 'none';
                  }
                });
                
                upgradesContainer.appendChild(upgradeLine);
              });
              
              // Add the upgrades container to the tooltip body
              body.appendChild(upgradesContainer);
            }
          }
          
          // Position the tooltip near the cursor
          const rect = cardItem.getBoundingClientRect();
          tooltip.style.left = rect.right + 10 + 'px'; // Position to the right of the card
          tooltip.style.top = rect.top + 'px'; // Align with top of the card
          
          // Show the tooltip
          tooltip.style.display = 'block';
        }
      });
      
      cardItem.addEventListener('mouseleave', () => {
        const tooltip = document.getElementById('card-tooltip');
        if (tooltip) {
          // Hide the tooltip
          tooltip.style.display = 'none';
        }
      });
      
      // Add the card item to the category container
      categoryContainer.appendChild(cardItem);
    });
    
    // Add the category container to the main container
    container.appendChild(categoryContainer);
  }
}

// Helper function to get card symbol by name
function getCardSymbolByName(cardName) {
 switch(cardName.toLowerCase()) {
    case 'pawn':
      return '♙';
    case 'knight':
      return '♘';
    case 'bishop':
      return '♗';
    case 'rook':
      return '♖';
    default:
      return '?'; // Fallback for unknown card names
  }
}

// Function to render the player's health and armor
export function renderHealth() {
  const healthDisplay = document.getElementById('health-display');
  if (!healthDisplay) {
    console.error('Health display container not found');
    return;
  }
  
  // Clear the container
  healthDisplay.innerHTML = '';
  
  // Create a container for hearts (permanent health)
 for (let i = 0; i < gameState.playerMaxHealth; i++) {
    const heart = document.createElement('span');
    heart.className = 'health-heart';
    heart.textContent = i < gameState.playerHealth ? '❤️' : '🤍'; // Use black heart for missing health
    healthDisplay.appendChild(heart);
  }
  
 // Create a container for shields (temporary armor)
  for (let i = 0; i < gameState.playerArmor; i++) {
    const shield = document.createElement('span');
    shield.className = 'health-armor';
    shield.textContent = '🛡️';
    healthDisplay.appendChild(shield);
  }
}

// Initialize the board rendering
renderBoard();